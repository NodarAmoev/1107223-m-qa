package Person;


import java.time.LocalDate;

public class Person {
    private int id;
    private String firstName;
    private String lastName;
    private LocalDate dateOfBirth;
    private long nin;
    private Gender gender;
    private Person(){}
    public Person(long nin){
        if(nin < 0)throw new RuntimeException("nin должно быть больше 0");
        this.nin= nin;
    }

    public Person(long nin , String lastName){
        this (nin);
        this.lastName = lastName;
    }

    public Person(Person original){
        this(original.nin, original.lastName);
        this.firstName =original.firstName;
        this.id = original.id;
        this.gender = original.gender;
        this.dateOfBirth = original.dateOfBirth;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        if (id < 0) throw new IllegalArgumentException("Error");
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        if (firstName == null || firstName.isEmpty()) throw new IllegalArgumentException("Имя не может быть пустым");
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        if (lastName == null || lastName.isEmpty()) throw new IllegalArgumentException("Имя не может быть пустым");
        this.lastName = lastName;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public long getNin() {
        return nin;
    }

    public void setNin(long nin) {
        if (nin <0 || String.valueOf(nin).length() <= 6) throw new IllegalArgumentException("Неккоректный налоговый номер" );
        this.nin = nin;
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }
}
