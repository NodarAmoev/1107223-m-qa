package Person;

import Person.Person;

import java.time.LocalDate;


public class Main {
    public static void main(String[] args) {
        Person katja = new Person(12345L);

        System.out.println(katja.getNin());
        System.out.println(katja.getFirstName());

        katja.setFirstName("Катя");
        System.out.println(katja.getFirstName());


        Person irina = new Person(23232L, "Irinovna");
        System.out.println(irina.getLastName());

        Person irinaClone = new Person(irina);
        System.out.println(irina == irinaClone);
        System.out.println(irina.getNin());
        System.out.println(irinaClone.getNin());



        irinaClone.setNin(11231314L);
        System.out.println(irina.getNin());
        System.out.println(irinaClone.getNin());











      /*  katja.id = 1;
        katja.firstName = "Katja";
        katja.lastName= "Smirnova";
        katja.dateOfBirth = LocalDate.of(2000,3,23);
        katja.nin = 234232L;
        katja.gender = Gender.FEMALE;

        System.out.println(katja.firstName);



        Person vasia = new Person();



        vasia.id = 2;
        vasia.firstName = "Vasia";
        vasia.lastName= "Smirnova";
        vasia.dateOfBirth = LocalDate.of(2001,3,23);
        vasia.nin = 234233L;
        vasia.gender = Gender.MALE;

        System.out.println(vasia.lastName);*/
    }
}