package Person;

public enum Gender {
    MALE,
    FEMALE,
    UNKNOW,
}
