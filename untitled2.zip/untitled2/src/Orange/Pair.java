package Orange;public class Pair {
}
