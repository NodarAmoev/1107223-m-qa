
public class Man {
}
