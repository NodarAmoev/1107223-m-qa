package AutoServis;

public class CarDrive {
    public static void main(String[] args) {
        //Car - Автомобиль
        Car pkw = new Car(240, "A3", "Audi");
        System.out.println(pkw.getInfoTheCar());
        pkw.goFast(120);

        System.out.println("---------------------------- \n");


        Car lkw = new Car(150, "Citan", "Mercedes-Benz");
        System.out.println(lkw.getInfoTheCar());
        lkw.goFast(80);

        System.out.println("---------------------------- \n");

        Car sportCar = new Car(570, "AMG-GT", "Mercedes-Benz");
        System.out.println(sportCar.getInfoTheCar());
        sportCar.goFast(50);


        System.out.println("---------------------------- \n");




        //Factory - Фабрика которая создает транспорт ит тд....
        Factory newPkw = new Factory();
        System.out.println(newPkw.getFactoryCar());

        Factory newLkw = new Factory();
        System.out.println(newLkw.getFactoryCar());

        Factory newSportCar = new Factory();
        System.out.println(newSportCar.getFactoryCar());




    }
}
