package AutoServis;
/*1 уровень сложности: Задание 1.
Создайте Package (щелчок правой кнопкой мыши на папке src -> New -> Package).
1 В созданном пакете создайте класс Автомобиль.
Создайте поля для типа автомобиля – грузовик, спорткар, легковой (можно сделать перечисление), мощность двигателя (сколько лошадиных сил), поля для марки и модели автомобиля
Одно из полей сделайте публичным, второе – без модификатора доступа, остальные – приватными.
Создайте объект этого класса в программе и попробуйте установить значения для полей. Какие поля возможно установить? Для приватных полей напишите геттеры и сеттеры.
2 Создайте класс Завод. Класс будет производить три вида автомобилей (иметь 3 метода) – спорткар, грузовик, легковой.
В основной программе создайте несколько автомобилей с помощью класса Завод.*/

public class Car {
    private String pkw;
    private String lkw;
    private String sportCar;
    public int motorPower;
    private String model;
    private String bradnOfTheCar;

    public Car(int motorPower, String model, String bradnOfTheCar) {
        this.motorPower = motorPower;
        this.model = model;
        this.bradnOfTheCar = bradnOfTheCar;
    }

    public String getPkw() {
        return pkw;
    }

    public void setPkw(String pkw) {
        this.pkw = pkw;
    }

    public String getLkw() {
        return lkw;
    }

    public void setLkw(String lkw) {
        this.lkw = lkw;
    }

    public String getSportCar() {
        return sportCar;
    }

    public void setSportCar(String sportCar) {
        this.sportCar = sportCar;
    }

    public int getMotorPower() {
        return motorPower;
    }

    public void setMotorPower(int motorPower) {
        this.motorPower = motorPower;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getBradnOfTheCar() {
        return bradnOfTheCar;
    }

    public void setBradnOfTheCar(String bradnOfTheCar) {
        this.bradnOfTheCar = bradnOfTheCar;
    }


    public String getInfoTheCar() {
        return "Информация о транспортном средстве " +
                "\n" + "Мощность мотора: " + this.motorPower +
                "\n" + "Модель: " + this.model +
                "\n" + "Брэнд: " + this.bradnOfTheCar;
    }

    public void goFast(int limit) {
        if (limit > 100) {
            System.out.println("Машина едет на всех парах");
        } else if (limit < 80 || limit > 0) {
            System.out.println("Машина едет медленно");
        } else {
            System.out.println("Машина припарковона");
        }

    }
}
