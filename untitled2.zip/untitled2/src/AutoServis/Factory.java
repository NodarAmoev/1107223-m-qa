package AutoServis;

public class Factory {
    public int id;
    public static int globalId = 1;

    public Factory() {
        this.id = globalId;
        globalId++;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Factory(int id) {
        this.id = id;
        this.id++;
    }

    public void pkw() {
        System.out.println("Создан Машина");
    }

    public void lkw() {
        System.out.println("Создан Грузовик");

    }

    public void sportCar() {
        System.out.println("Создана Спортивная машина");
    }

    public String getFactoryCar(){
        return "ID: " + this.getId();
    }
}
