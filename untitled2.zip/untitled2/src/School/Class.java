package School;

public class Class {
    public static void main(String[] args) {

        Student str = new Student("Nodari", "Amoev");
        System.out.println(str.getInfoClass());
        str.setNumberGruppe(23);
        System.out.println("Номер группы: " + str.getNumberGruppe());

        System.out.println("-----------------------------");


        Student str2 = new Student("Андрей", "Синегубов");
        System.out.println(str2.getInfoClass());
        str2.setNumberGruppe(23);
        str2.moveToNextGroup();
        System.out.println("Номер группы: " + str2.getNumberGruppe());


        System.out.println("-----------------------------");


        Student originalStudent = new Student("Nodar", "Amoev");
        System.out.println(originalStudent.getInfoClass());

        Student cloneStudent = new Student(originalStudent);
        System.out.println(originalStudent == cloneStudent);
        System.out.println(originalStudent.getFirstName());
        System.out.println(cloneStudent.getFirstName());

        cloneStudent.setFirstName("Петя");
        System.out.println(originalStudent.getFirstName());
        System.out.println(cloneStudent.getFirstName());


    }
}