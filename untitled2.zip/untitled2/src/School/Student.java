package School;

import Person.Person;

/*Создайте класс Студент, имеющий поля имя, фамилия и номер группы.
1 Напишите минимум 2 конструктора для класса Студент.
2 Реализуйте геттеры и сеттеры для класса Студент.
В сеттере сделайте проверку, что номер группы положительный.
В противном случае бросьте исключение throw new RuntimeException(“Номер группы должен быть положительным”);
3 Создайте метод «перейти в следующую группу».
При вызове метода студент переводится в следующую по номеру группу (чтобы не сдавать экзамены  ).
4 Создайте в программе объект студента.
5 Добавьте клонирующий конструктор к классу Студент.
В программе склонируйте созданный ранее объект. Проверьте с помощью ==, что объекты имеют разные ссылки в памяти.
 Затем измените одно из полей оригинального студента.
 Изменилось ли то же поле у клона?*/
public class Student {
    public String firstName;
    public String lastName;
    public int numberGruppe;

    public Student(Student original) {
        this(original.firstName, original.lastName);
        this.firstName = original.firstName;
        this.lastName = original.lastName;
        this.numberGruppe = original.numberGruppe;
    }

    public Student(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public Student(int numberGruppe, String lastName) {
        this.numberGruppe = numberGruppe;
        this.lastName = lastName;
    }


    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getNumberGruppe() {
        return numberGruppe;
    }

    public void setNumberGruppe(int numberGruppe) {
        if (numberGruppe < 0) throw new IllegalArgumentException("“Номер группы должен быть положительным”");
        this.numberGruppe = numberGruppe;
    }

    public void moveToNextGroup() {
        this.numberGruppe++; // Увеличиваем номер группы на 1
    }

    public String getInfoClass() {
        return "Имя: " + this.firstName +
                "\n" + "Фамилия: " + this.lastName;
    }
}
